from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI
from pydantic import BaseModel
from .service import handle
from .schemas import AssistantResponse

app = FastAPI(title="eSchool Search Assistant")


class Query(BaseModel):
    request: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/search", response_model=AssistantResponse)
def search_endpoint(q: Query):
    return handle(q.request)