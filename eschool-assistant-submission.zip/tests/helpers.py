"""Shared test doubles."""
from pathlib import Path
from types import SimpleNamespace

FIXTURES = Path(__file__).parent / "fixtures"


def read_fixture(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


class FakeClient:
    """Mimics anthropic.Anthropic().messages.create and records every call."""

    def __init__(self, content=None, error=None):
        self._content, self._error = content, error
        self.calls: list[dict] = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if self._error:
            raise self._error
        return SimpleNamespace(content=self._content)

    @property
    def last_user_message(self) -> str:
        return self.calls[-1]["messages"][0]["content"]


def tool_block(payload: dict):
    return SimpleNamespace(type="tool_use", input=payload)


def client_returning(payload: dict) -> FakeClient:
    return FakeClient([tool_block(payload)])